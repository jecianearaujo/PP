<?php

namespace App\Http\Controllers;
use Illuminate\View\View;
use GuzzleHttp\Client;

use Illuminate\Http\Request;

class ColaboradoresController extends Controller
{
    private $urlTangerino = "https://employer.tangerino.com.br/";

    public function __construct() {
        define('TANGERINO_API', config('tangerino.api', 'teste'));
    }

    public function index(): View
    {
        $url = $this->urlTangerino . "employee/find-all";
        $client = new Client(['verify' => false]);

        $response = $client->request('GET', $url, [
            'headers' => [
                'Authorization' => TANGERINO_API       
            ]
        ]);

        $colaboradores = json_decode($response->getBody(), true);

        return view('colaboradores.index', ['colaboradores' => $colaboradores['content']]);
    }

    public function show(Request $request): View
    {
        $id = $request->input('id');
        $url = $this->urlTangerino . "employee/find";
        $client = new Client(['verify' => false]);

        $response = $client->request('GET', $url, [
            'query' => [
                'tangerinoId' => $id
            ],
            'headers' => [
                'Authorization' => TANGERINO_API       
            ]
        ]);

        $colaborador = json_decode($response->getBody(), true);

        return view('colaboradores.show', ['colaborador' => $colaborador]);
    }
}
