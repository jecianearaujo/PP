<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\View\View;
use GuzzleHttp\Client;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ColaboradoresController extends Controller
{
    private $urlTangerino = "https://employer.tangerino.com.br/";
    private $client;
    private $pageSize = 30;

    public function __construct()
    {
        define('TANGERINO_API', config('tangerino.api', 'teste'));
        $this->client = new Client([
            'verify' => false,
            'headers' => ['Authorization' => TANGERINO_API]
        ]);
    }

    public static function syncEmployees()
    {
        $client = new Client([
            'verify' => false,
            'headers' => ['Authorization' => "Basic Y2Y2NjRhYmZiMzk3NDU5ODhlNTJmYWZjMTBjOTkwYzk6MGU1ZjViZDBlNTE0NDlmMjhkMjQzOGY4ZWQ4MTRkYzA="]
        ]);

        $url = "https://employer.tangerino.com.br/employee/find-all";

        $isLastPage = false;
        $page = 1;
        $users = [];

        while (!$isLastPage) {
            $response = $client->get($url, ['query' => [
                'size' => 100,
                'page' => $page
            ]]);

            $tempResponse = json_decode($response->getBody(), true);

            foreach ($tempResponse['content'] as $user) {
                $hashUserPassword = Hash::make($user["pin"]);
                array_push($users, [
                    "id" => $user["id"],
                    "name" => $user["name"],
                    "email" => array_key_exists("email", $user) ? $user["email"] : null,
                    "cpf" => array_key_exists("cpf", $user) ? $user["cpf"] : null,
                    "active" => array_key_exists("email", $user) ? true : false,
                    "password" => $hashUserPassword
                ]);
            }
            $isLastPage = $tempResponse['last'];
            $page++;
        }

        User::upsert($users, ['id']);
    }

    public static function getDateNowInTimestamp(int $day): \DateTime
    {
        $date = new \DateTime(date("Y-m-{$day}"));
        $date->setTimezone(new \DateTimeZone('UTC'));
        return $date;
    }

    public static function getPoints(int $employeeId, \GuzzleHttp\Client $client, string $start = null, string $end = null): array|bool
    {   
        $urlTimeSheet = "https://apis.tangerino.com.br/punch/";
        $defaultDateFormat = 'Y-m-d';

        $start = \DateTime::createFromFormat($defaultDateFormat, $start);
        $end = \DateTime::createFromFormat($defaultDateFormat, $end);

        if (!$start)
            $start = ColaboradoresController::getDateNowInTimestamp(01);
        if (!$end)
            $end = ColaboradoresController::getDateNowInTimestamp(30);

        $start = $start->getTimestamp() * 1000;
        $end = $end->getTimestamp() * 1000;

        $data = [];
        $isLastPage = false;
        $page = 1;

        while (!$isLastPage) {
            $response = $client->get($urlTimeSheet, ['query' => [
                'startDate' => $start,
                'endDate' => $end,
                'size' => 31,
                'page' => $page,
                'employeeId' => $employeeId
            ]]);

            $tempResponse = json_decode($response->getBody(), true);
            $data = array_merge($data, $tempResponse["content"]);
            $isLastPage = $tempResponse['last'];
            $page++;
        }

        return !empty($data) ? ['content' => $data] : false;
    }

    public function index(Request $request): View
    {
        if($request->input('colaborador')){
            $colaborador = strtoupper($request->input('colaborador')) . "%";
            $users = User::where('name', 'LIKE', $colaborador)->with('pendencie')->get();
            return view('colaboradores.index', ['users' => $users]);
        }
        $users = User::with('pendencie')->get();

        return view('colaboradores.index', ['users' => $users]);
    }

    public function show(Request $request): View
    {
        $startDate = $request->input('startDate');
        $endDate = $request->input('endDate');
        $id = $request->input('id');

        $url = $this->urlTangerino . "employee/find";

        $response = $this->client->get($url, ['query' => ['tangerinoId' => $id]]);

        $colaborador = json_decode($response->getBody(), true);
        $colaborador['id'] = $id;

        $data = ['colaborador' => $colaborador];

        $timeSheet = $this->getPoints($id, $this->client, $startDate, $endDate);
        if ($timeSheet)
            $data['timeSheet'] = $timeSheet;

        return view('colaboradores.show', $data);
    }
}
