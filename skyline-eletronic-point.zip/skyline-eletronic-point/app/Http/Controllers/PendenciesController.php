<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;

use App\Models\User;
use App\Models\Pendencies;
use Illuminate\View\View;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;

class PendenciesController extends Controller
{

    public function index(Request $request): View
    {
        if(!Auth::user()->admin){
            $pendencies = Pendencies::where('solved', false)
                ->where('employee_id', Auth::user()->id)
                ->with('user')->get();
        }else{
            if($request->input('colaborador')){
                $colaborador = strtoupper($request->input('colaborador')) . "%";
                $pendencies = Pendencies::whereHas('user', function($query) use ($colaborador) {
                    $query->where('name', 'LIKE', $colaborador);
                })->with('user')->get();
                return view('pendencies.index', ['pendencies' => $pendencies]);
            }
            $pendencies = Pendencies::where('solved', false)->with('user')->get();
        }
        return view('pendencies.index', ['pendencies' => $pendencies]);
    }

    public static function getGpsPendencies(): void
    {
        $client = new Client([
            'verify' => false,
            'headers' => ['Authorization' => "Basic Y2Y2NjRhYmZiMzk3NDU5ODhlNTJmYWZjMTBjOTkwYzk6MGU1ZjViZDBlNTE0NDlmMjhkMjQzOGY4ZWQ4MTRkYzA="]
        ]);

        $users = User::pluck('id');

        foreach ($users as $user) {
            $points = ColaboradoresController::getPoints($user, $client, null, null);
            if (is_array($points)) {
                foreach ($points['content'] as $point) {
                    if ($point["status"] == "PENDING" && ($point['locationIn'] == null || $point['locationOut'] == null)) {
                        $tempData = [
                            'id' => $point['id'],
                            'employee_id' => $user,
                            'description' => "GPS DESATIVADO",
                            'date_in' => $point['dateIn'],
                            'date_out' => $point['dateOut'],
                        ];
                        Pendencies::upsert($tempData, ['id']);
                    }
                }
            }
        }
    }

}
