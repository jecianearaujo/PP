<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

use GuzzleHttp\Client;

class LoginController extends Controller
{
    private $urlTangerino = "https://employer.tangerino.com.br/";

    public function __construct() {
        define('TANGERINO_API', config('tangerino.api', 'teste'));
    }

    /**
     * Handle an authentication attempt.
     */
    public function authenticate(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        $url = $this->urlTangerino . "employee/auth";
        $client = new Client(['verify' => false]);

        $response = $client->request('POST', $url, [
            'body' => [
                'login' => 'teste',
                'password' => 'teste'
            ],
            'headers' => [
                'Authorization' => TANGERINO_API       
            ]
        ]);

        $colaboradores = json_decode($response->getBody(), true);


        
 
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
 
            return redirect()->intended('dashboard');
        }
 
        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('email');
    }
}

