<?php

namespace App\Console\Commands;

use App\Http\Controllers\PendenciesController;
use Illuminate\Console\Command;

class GetPendencies extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:get-pendencies';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'get Gps pendencies';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        PendenciesController::getGpsPendencies();
    }
}
