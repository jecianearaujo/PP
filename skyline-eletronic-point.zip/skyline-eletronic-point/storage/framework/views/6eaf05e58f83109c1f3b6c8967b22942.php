<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="jeciane">
    <title>SKYLINE</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/colaboradores.css')); ?>">

</head>

<body>

    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>

        <div class="container-fluid">

            <section class="mt-5">

                <article>
                    <p>Nome: <?php echo e($colaborador['name']); ?></p>
                    <?php if(array_key_exists('cpf', $colaborador)): ?>
                        <p>Cpf: <?php echo e($colaborador['cpf']); ?></p>
                    <?php endif; ?>
                    <p>Email: <?php echo e($colaborador['email']); ?></p>
                    <?php if(array_key_exists('phone', $colaborador)): ?>
                        <p>Celular: <?php echo e($colaborador['phone']); ?></p>
                    <?php endif; ?>
                    <p>Cargo: <?php echo e($colaborador['jobRoleDTO']['description']); ?></p>
                </article>

            </section>

            <section>
                
                <div>
                    <form action="" method="GET">
                        <div class="input-group">
                            <span class="input-group-text">Filtrar por datas</span>
                            <input type="date" pattern="\d{2}\/\d{2}\/\d{4}" aria-label="Inicio" class="form-control" value="<?php echo e(old('startDate', request()->input('startDate'))); ?>" placeholder="Data de inicio" name="startDate" required>
                            <input type="date" pattern="\d{2}\/\d{2}\/\d{4}" aria-label="Fim" class="form-control" value="<?php echo e(old('endDate', request()->input('endDate'))); ?>" placeholder="Data de fim" name="endDate" required>
                            <input type="hidden" value="<?php echo e($colaborador['id']); ?>" name="id">
                            <button class="btn btn-primary" style="background-color: rgb(166, 237, 154); color: rgb(42, 131, 40); border: none;" type="submit">Buscar</button>
                        </div>
                    </form>
                </div>

                <div class="table-responsive table-mb">

                    <table class="table caption-top table-sm mt-2">
                        <caption><?php echo e(count($timeSheet['content'])); ?> registros</caption>
                        <thead>
                            <th>
                                <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Data</p>
                            </th>
                            <th>
                                <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Entrada</p>
                            </th>
                            <th>
                                <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Saida</p>
                            </th>
                            <th>
                                <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Status</p>
                            </th>
                        </thead>
                        <tbody>
                            <?php if(isset($timeSheet)): ?>
                                <?php $__currentLoopData = $timeSheet['content']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="table-warning">
                                        <td><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d', $point['date'])->format('d/m/Y')); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::createFromTimestampMs($point['dateIn'])->format('d/m/Y H:i:s')); ?></td>
                                        <?php if($point['dateOut'] != null): ?>
                                            <td><?php echo e(\Carbon\Carbon::createFromTimestampMs($point['dateOut'])->format('d/m/Y H:i:s')); ?></td>
                                        <?php else: ?>
                                            <td>Vazio</td>
                                        <?php endif; ?>
                                        <td>
                                            <?php if($point['status'] == "PENDING"): ?>
                                                Pendente
                                            <?php elseif($point['status'] == "APPROVED"): ?>
                                                Aprovado
                                            <?php elseif($point['status'] == "REJECTED"): ?>
                                                Rejeitado
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </div>

        <div class="modal fade" id="modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content" id="modal-colaboradores">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5 p-2" id="modal-label">Ações</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-sm table-borderless" id="table-colaboradores-modal">
                            <thead id="thead-modal">
                                <th>Data</th>
                                <th>Observações</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>06/11/2023 - 07:30</td>
                                    <td>GPS desabilitado</td>
                                </tr>
                                <tr>
                                    <td>06/11/2023 - 07:30</td>
                                    <td>GPS desabilitado</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </main>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\d4rkm0d3\Documents\jeciane\skyline-eletronic-point\resources\views/colaboradores/show.blade.php ENDPATH**/ ?>