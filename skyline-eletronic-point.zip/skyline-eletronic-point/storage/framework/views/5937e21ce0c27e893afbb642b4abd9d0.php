

<?php $__env->startSection('title', 'SKYLINE'); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layout.index.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main>

    <div class="container position-fixed centered">
        <section class="">
            <article>
                <h2 class="text-white">Bem-Vindo(a) <?php echo e(Auth::user()->name); ?>!</h2>
                <h3 id="data-notificacoes" class="ms-lg-4 ms-md-4 text-white">
                    <span id="data"><?php echo e(date('d/m/Y', strtotime('now'))); ?> | </span>
                    <span id="notificacoes-qntd"><?php echo e($countPendencies); ?> Notificações</span>
                </h3>
            </article>
        </section>

        <section class="mt-4">
            <h4 id="pendencias">Pendências</h4>

            <div class="container" id="pendencias-grid">
                <div class="row column-gap-3">
                    <div class="col" onclick="location.href='<?php echo e(route('pendencies.index')); ?>'">
                        <h3 class="m-3">Notificações</h3>
                        <div class="m-3 d-flex justify-content-between align-items-center">
                            <div>
                                <h1 class="pendencia-qntd"><?php echo e($countPendencies); ?></h1>
                            </div>
                            <div class="alert rounded-circle">
                                <img src="img/alert.png" alt="alerta" width="60">
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <h3 class="m-3">Resolvidos</h3>
                        <div class="m-3 d-flex justify-content-between align-items-center">
                            <div>
                                <?php if(Auth::user()->admin == 1): ?>
                                    <h1 class="pendencia-qntd">
                                        <?php echo e(\App\Models\Pendencies::where('solved', true)->count()); ?>

                                    </h1>
                                <?php else: ?>
                                    <h1 class="pendencia-qntd">
                                        <?php echo e(\App\Models\Pendencies::where('solved', true)->where('employee_id', Auth::user()->id)->count()); ?>

                                    </h1>
                                <?php endif; ?>
                                
                            </div>
                            <div class="alert rounded-circle">
                                <img src="img/alert.png" alt="alerta" width="60">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

</main>

<?php echo $__env->make('layout.index.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeciane\Desktop\skyline-eletronic-point\skyline-eletronic-point\resources\views/index.blade.php ENDPATH**/ ?>