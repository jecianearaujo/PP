<footer>
    <nav class="navbar fixed-bottom footer-normal">
        <ul class="d-flex mx-auto">
            <a href="/"><li class="text-white me-2">Inicio</li></a>
            <a href="<?php echo e(route('pendencies.index')); ?>"><li class="text-white me-2">Pendencias</li></a>
            <a href="<?php echo e(route('dashboard')); ?>"><li class="text-white me-2">Horas trabalhadas</li></a>
            <a href="<?php echo e(route('colaboradores.index')); ?>"><li class="text-white">Colaboradores</li></a>
        </ul>
    </nav>
</footer><?php /**PATH C:\Users\d4rkm0d3\Desktop\skyline-eletronic-point\resources\views/layout/footer.blade.php ENDPATH**/ ?>