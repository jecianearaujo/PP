<header>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="SKYLINE" width="160">
            </a>
            <ul class="navbar-nav ml-auto">

                <li class="nav-item">
                    <div class="row align-items-center">
                        <div class="col-sm-3">
                            <img src="<?php echo e(asset('img/user.png')); ?>" alt="Usuário" width="56">
                        </div>
                        <div class="col user-color">
                            <h4><?php echo e(Auth::user()->name); ?></h4>
                            <h4>Administrador</h4>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</header><?php /**PATH C:\Users\d4rkm0d3\Desktop\skyline-eletronic-point\resources\views/layout/header.blade.php ENDPATH**/ ?>