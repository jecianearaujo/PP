<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    <style>
        body {
            background-color: rgb(93, 143, 85);
        }
    </style>

</head>
<body>

    <div class="container">

        <?php if(session()->has('message')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <main>
            
            <section class="login">

                <div class="text-center mt-2">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" width="240px">
                </div>

                <h2 class="text-center text-white my-4">LOGIN</h2>

                <form action="<?php echo e(route('login.authenticate')); ?>" method="post" class="mx-4">
                    <?php echo csrf_field(); ?>
                    <input class="form-control form-control-lg form-input-bg rounded-pill mb-3" type="text" placeholder="Email" aria-label="email" name="email" required>

                    <input class="form-control form-control-lg form-input-bg rounded-pill mb-4" type="password" placeholder="Senha" aria-label="password" name="password" required>

                    <div class="text-center mb-5">
                        <button class="btn btn-primary rounded-pill px-4" type="submit">Entrar</button>
                    </div>
                </form>

            </section>
            
        </main>
    </div>
    
    
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\d4rkm0d3\Desktop\skyline-eletronic-point\resources\views/auth/login.blade.php ENDPATH**/ ?>