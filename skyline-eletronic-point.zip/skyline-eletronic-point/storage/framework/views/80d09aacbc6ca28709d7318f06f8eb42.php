<footer>
    <nav class="navbar fixed-bottom footer-normal">
        <ul class="d-flex mx-auto">
            <a href="<?php echo e(route('dashboard')); ?>"><li class="text-white me-2">Inicio</li></a>
            <a href="<?php echo e(route('pendencies.index')); ?>"><li class="text-white me-2">Pendências</li></a>
            <a href="<?php echo e(route('dashboard')); ?>"><li class="text-white me-2">Pendências resolvidas</li></a>
            <?php if(!Auth::guest() && Auth::user()->admin == 1): ?>
                <a href="<?php echo e(route('colaboradores.index')); ?>"><li class="text-white">Colaboradores</li></a>
            <?php endif; ?>
        </ul>
    </nav>
</footer><?php /**PATH C:\Users\jeciane\Desktop\skyline-eletronic-point\skyline-eletronic-point\resources\views/layout/footer.blade.php ENDPATH**/ ?>