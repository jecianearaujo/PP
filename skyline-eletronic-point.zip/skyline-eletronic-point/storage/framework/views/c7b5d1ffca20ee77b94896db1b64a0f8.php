<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="jeciane">
    <title>SKYLINE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/colaboradores.css')); ?>">

</head>

<body>

    <header>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="<?php echo e(asset('img/logo.png')); ?>" alt="SKYLINE" width="160">
                </a>
                <ul class="navbar-nav ml-auto">

                    <li class="nav-item">
                        <div class="row align-items-center">
                            <div class="col-sm-2">
                                <!-- <a class="nav-link" href="#"> -->
                                <img src="<?php echo e(asset('img/user.png')); ?>" alt="Usuário" width="56">
                                <!-- </a> -->
                            </div>
                            <div class="col user-color">
                                <h4>JECIANE DANTAS DE ARAUJO</h4>
                                <h4>Administrador</h4>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </header>

    <main>

        <div class="container-fluid">

            <section class="mt-5">
                <form action="" method="get">
                    <div class="mb-3">
                        <label for="colaborador" class="form-label ms-4" id="lbl">Colaborador</label>
                        <input type="text" class="form-control" id="colaborador">
                    </div>
                </form>

                <table class="table table-sm mt-5">
                    <thead>
                        <th>Ações</th>
                        <th>Colaborador</th>
                        <th>Data</th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $colaboradores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colaborador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><img src="<?php echo e(asset('img/warning.png')); ?>" alt="" width="32" data-bs-toggle="modal" data-bs-target="#modal"></td>
                            <td><?php echo e($colaborador['name']); ?></td>
                            <td>03/05/2023</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <tr>
                            <td><img src="<?php echo e(asset('img/warning.png')); ?>" alt="" width="32" data-bs-toggle="modal" data-bs-target="#modal"></td>
                            <td>Matheus Felipe Ramalho Menino</td>
                            <td>03/05/2023</td>
                        </tr> -->
                    </tbody>
                </table>
            </section>

        </div>

        <div class="modal fade" id="modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content" id="modal-colaboradores">
                <div class="modal-header">
                  <h1 class="modal-title fs-5 p-2" id="modal-label">Ações</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table class="table table-sm table-borderless" id="table-colaboradores-modal">
                    <thead id="thead-modal">
                        <th>Data</th>
                        <th>Observações</th>
                    </thead>
                    <tbody>
                        <tr>
                        <td>06/11/2023 - 07:30</td>
                        <td>GPS desabilitado</td>
                    </tr>
                    <tr>
                        <td>06/11/2023 - 07:30</td>
                        <td>GPS desabilitado</td>
                    </tr>
                    </tbody>
                      </table>
                </div>
              </div>
            </div>
          </div>
                   

    </main>

    <footer>
        <nav class="navbar fixed-bottom footer-normal"></nav>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>
</body>

</html><?php /**PATH C:\Users\d4rkm0d3\Documents\jeciane\skyline-eletronic-point\resources\views/colaboradores.blade.php ENDPATH**/ ?>