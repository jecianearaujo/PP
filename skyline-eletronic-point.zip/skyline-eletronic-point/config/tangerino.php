<?php

return [
    'api' => env('TANGERINO_API_KEY')
];