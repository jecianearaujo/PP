<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    {{-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> --}}

    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">

    <style>
        body {
            background-color: rgb(93, 143, 85);
        }
    </style>

</head>
<body>

    <div class="container">

        @if(session()->has('message'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('message') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        @endif

        <main>
            
            <section class="login">

                <div class="text-center mt-2">
                    <img src="{{ asset('img/logo.png') }}" alt="" width="240px">
                </div>

                <h2 class="text-center text-white my-4">LOGIN</h2>

                <form action="{{ route('login.authenticate') }}" method="post" class="mx-4">
                    @csrf
                    <input class="form-control form-control-lg form-input-bg rounded-pill mb-3" type="text" placeholder="Email" aria-label="email" name="email" required>

                    <input class="form-control form-control-lg form-input-bg rounded-pill mb-4" type="password" placeholder="Senha" aria-label="password" name="password" required>

                    <div class="text-center mb-5">
                        <button class="btn btn-primary rounded-pill px-4" type="submit">Entrar</button>
                    </div>
                </form>

            </section>
            
        </main>
    </div>
    
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>

</body>
</html>