<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="jeciane">
    <title>SKYLINE</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">

    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('css/colaboradores.css') }}">

</head>

<body>

    @include('layout.header')

    <main>

        <div class="container-fluid">

            <section class="mt-5">
                <form action="{{ route('colaboradores.index') }}" method="get">
                    <div class="mb-3">
                        <label for="colaborador" class="form-label" id="lbl">Colaborador</label>
                        <input type="text" class="form-control" id="colaborador" name="colaborador">
                    </div>
                </form>

                <div class="table-responsive table-mb">

                <table class="table caption-top table-sm mt-2">
                    <caption>{{ count($users) }} colaboradores</caption>
                    <thead>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Ações</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Colaborador</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Email</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Data</p></th>
                    </thead>
                    <tbody>
                        @foreach ($users as $colaborador)
                            <tr>
                                <td>
                                    @if (count($colaborador->pendencie) > 0)
                                    <img src="{{ asset('img/warning.png') }}" alt="" width="32" data-bs-toggle="modal" data-bs-target="#modal" user-id="{{ $colaborador->id }}"></td>
                                    @endif
                                <td><a
                                        href="{{ route('colaboradores.show', ['id' => $colaborador->id]) }}">{{ $colaborador->name }}</a>
                                </td>
                                <td>
                                    @if ($colaborador->email)
                                        {{ $colaborador->email }}
                                    @else
                                        Não possui
                                    @endif

                                <td>03/05/2023</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>

                </div>

            </section>

        </div>

        <div class="modal fade" id="modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content" id="modal-colaboradores">
                <div class="modal-header">
                  <h1 class="modal-title fs-5 p-2" id="modal-label">Ações</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table class="table table-sm table-borderless" id="table-colaboradores-modal">
                    <thead id="thead-modal">
                        <th>Data</th>
                        <th>Observação</th>
                        <th>Ação</th>
                    </thead>
                    <tbody>
                        
                    </tbody>
                      </table>
                </div>
              </div>
            </div>
          </div>


    </main>

    @include('layout.footer')

    <script src="{{ asset('js/bootstrap.min.js') }}"></script>

    <script>

        const modal = document.getElementById('modal')
        if (modal) {
        modal.addEventListener('show.bs.modal', event => {
            
            const button = event.relatedTarget

            const userId = button.getAttribute('user-id')

            const modalTitle = modal.querySelector('.modal-title')
            const modalBody = modal.querySelector('.modal-body')

            const table = document.getElementById('table-colaboradores-modal');

            fetch(`{{ route('pendencies.find') }}?id=${userId}`)
                .then(response => response.json())
                .then(data => {
                    console.log(data);

                    const rows = table.querySelector('tbody').querySelectorAll("tr");

                    rows.forEach(row => {
                        row.remove();
                    });

                    data.forEach(element => {
                        const newRow = document.createElement('tr');
    
                        const date = new Date(element.date_in);
                        if(date === null){
                            dateFormatted = "vazio";
                        }else {
                            dateFormatted = `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
                        }

                        const dateCell = document.createElement('td');
                        dateCell.textContent = `${dateFormatted}`;
                        const observacoesCell = document.createElement('td');
                        observacoesCell.textContent = `${element.description}`;
                        const acaoCell = document.createElement('td');
                        const acaoBtn = document.createElement('button');
                        acaoBtn.textContent = "resolver";
                        acaoBtn.classList.add("btn", "btn-sm", "rounded-pill");
                        acaoBtn.style.backgroundColor = "rgb(166, 237, 154)";
                        acaoBtn.onclick = () => solvePendencie(element.id);
                        acaoCell.appendChild(acaoBtn);

                        newRow.appendChild(dateCell);
                        newRow.appendChild(observacoesCell);
                        newRow.appendChild(acaoCell);
    
                        table.querySelector('tbody').appendChild(newRow);
                        
                    });

                })
                .catch(error => {
                    console.error(error);
            });
        })
    }

    function solvePendencie(id)
    {
        fetch('{{ route('pendencies.solve') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id }),
            })
            .then(response => response.json())
            .then(data => {
                window.location.reload();
            })
            .catch(error => {
                console.error(error);
            });
        }

    </script>

</body>

</html>
