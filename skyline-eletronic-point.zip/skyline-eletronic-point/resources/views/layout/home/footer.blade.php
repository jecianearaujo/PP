<footer>
    <nav class="navbar fixed-bottom footer-normal" id="navbar-index">
        <div class="container d-flex justify-content-center">
            <div class="row d-flex align-items-center">
                <div class="col-1 me-5">
                    <a href="{{ route('dashboard') }}"><img src="{{ asset('img/relogio.png') }}" width="60" alt=""></a>
                </div>
                <div class="col-1">
                    <a href="{{ route('dashboard') }}"><img src="{{ asset('img/sino.png') }}" width="60" alt=""></a>
                </div>
                <div class="col ms-4 d-none d-md-block d-xl-block d-xxl-none">
                    <h4 class="text-white text-center py-4 px-3 rounded-pill" id="footer-message">Suas notificações e pendências aqui!</h4>
                </div>
            </div>
            
        </div>
        </div>
    </nav>

</footer>