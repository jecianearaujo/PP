<footer class="fixed-bottom">
    <div class="d-flex justify-content-between">
        <div class="triangular-box me-5">
            <div class="d-flex justify-content-center">
                <h1 id="text-contact-footer" class="text-white">Fale com a gente, estamos online!</h1>
            </div>
        </div>
        <div>
            <div class="d-flex justify-content-between align-items-center">
                <div class="me-3 p-3 rounded-circle border border-3 border-black img-contact">
                    <a href="https://wa.me/+558499790545"><img class="img-contact" src="img/whatsapp-contact.png" alt="" width="60"></a>
                </div>
                <div class="me-3 rounded-circle p-3 border border-3 border-black img-contact">
                    <a href="https://www.instagram.com/slupsorvetes/"><img class="img-contact" src="img/instagram-contactor.png" alt="" width="60"></a>
                </div>
            </div>
        </div>
    </div>
</footer>