<footer>
    <nav class="navbar fixed-bottom footer-normal">
        <ul class="d-flex mx-auto">
            <a href="{{ route('dashboard') }}"><li class="text-white me-2">Inicio</li></a>
            <a href="{{ route('pendencies.index') }}"><li class="text-white me-2">Pendências</li></a>
            <a href="{{ route('dashboard') }}"><li class="text-white me-2">Pendências resolvidas</li></a>
            @if(!Auth::guest() && Auth::user()->admin == 1)
                <a href="{{ route('colaboradores.index') }}"><li class="text-white">Colaboradores</li></a>
            @endif
        </ul>
    </nav>
</footer>