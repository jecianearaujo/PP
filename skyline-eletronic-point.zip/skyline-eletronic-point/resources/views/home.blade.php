@extends('layout.base')

@section('title', 'SKYLINE - Home')

@section('head')
<style>
    .auth-btn {
        top: 20px;
        right: 15px;
    }

    #login-btn {
        color: #1b761b;
    }

    #logout-btn {
        color: rgb(124, 179, 115);
    }

    .auth-btn:hover{
        color: #165f16 !important;
    }
</style>
@endsection

@section('content')

    <main style="height: 100vh;">

        <article>
            <h5 class="text-white text-center d-inline-block" id="greetings-user">
                Bem-Vindo(a) @if(Auth::user()) {{Auth::user()->name}} @endif
            </h5>
        </article>

        @if(Auth::guest())
            <button class="btn bg-light rounded-pill position-fixed auth-btn" id="login-btn" onclick="window.location.href='{{ route('login') }}'">Entrar</button>
        @else
            <button class="btn bg-danger rounded-pill position-fixed auth-btn" id="logout-btn" onclick="window.location.href='{{ route('login.logout') }}'">Sair</button>
        @endif

        <img src="img/logo.png" class="position-fixed img-fluid centered" alt="">

    </main>

    @include('layout.footer')

@endsection