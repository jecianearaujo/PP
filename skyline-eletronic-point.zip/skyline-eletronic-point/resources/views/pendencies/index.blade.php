@extends('layout.base')

@section('title', 'SKYLINE - Pendências')

@section('head')
<link rel="stylesheet" href="{{ asset('css/colaboradores.css') }}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endsection

@section('content')

    @include('layout.header')

    @include('layout.alerts')

    @include('layout.action_btns')

    <main>

        <div class="container-fluid">

            <section class="mt-2">
                @if(Auth::user()->admin)

                <div class="row">
                    <div class="col-md-6">
                        <form action="{{ route('pendencies.index') }}" method="get">
                            <div class="mb-3">
                                <div class="col">
                                    <label for="colaborador" class="form-label text-secondary-emphasis" id="lbl">Colaborador</label>
                                </div>
                                <div class="position-relative">
                                    <input type="text" id="colaborador" placeholder="Digite aqui">
                                    <button id="btn-search" type="submit">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" width="30px" height="30px"><path d="M 21 3 C 11.621094 3 4 10.621094 4 20 C 4 29.378906 11.621094 37 21 37 C 24.710938 37 28.140625 35.804688 30.9375 33.78125 L 44.09375 46.90625 L 46.90625 44.09375 L 33.90625 31.0625 C 36.460938 28.085938 38 24.222656 38 20 C 38 10.621094 30.378906 3 21 3 Z M 21 5 C 29.296875 5 36 11.703125 36 20 C 36 28.296875 29.296875 35 21 35 C 12.703125 35 6 28.296875 6 20 C 6 11.703125 12.703125 5 21 5 Z"/></svg>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-6 d-flex flex-column justify-content-end">
                        <div class="mb-3">
                        <div class="col"></div>
                        <div class="col" style="text-align: end">
                            <button class="btn" id="btn-pendencie-refresh" onclick="window.location.href = '{{ route('pendencies.refresh') }}';">
                                <img src="{{ asset('img/refresh_btn.svg') }}" alt="atualizar">
                            </button>
                        </div>
                    </div>
                    </div>

                </div>
                @endif

                <div class="table-responsive table-mb">

                <table class="table caption-top table-sm mt-2">
                    <caption>{{ count($pendencies) }} pendências</caption>
                    <thead>
                        @if(Auth::user()->admin)
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Ações</p></th>
                        @endif
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Colaborador</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Descrição</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Entrada</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Saída</p>
                        </th>
                    </thead>
                    <tbody>
                        @foreach ($pendencies as $pendencie)
                            <tr>
                                @if(Auth::user()->admin)
                                    <td><button class="btn btn-primary btn-sm rounded-pill form-input-bg" onclick="solvePendencie({{ $pendencie->id }})">Resolver</button></td>
                                    <td>
                                        <a href="{{ route('colaboradores.show', ['id' => $pendencie->user->id]) }}">{{ $pendencie->user->name }}</a>
                                        
                                        </td>
                                    @else
                                        <td>{{ $pendencie->user->name }}</td>
                                    @endif
                                    
                                <td>{{ $pendencie->description }}</td>
                                @if ($pendencie->date_in != null)
                                    <td>{{ \Carbon\Carbon::createFromTimestampMs($pendencie->date_in)->format('d/m/Y H:i:s')}}</td>
                                @else
                                    <td>Vazio</td>
                                @endif
                                @if ($pendencie->date_out != null)
                                    <td>{{ \Carbon\Carbon::createFromTimestampMs($pendencie->date_out)->format('d/m/Y H:i:s')}}</td>
                                @else
                                    <td>Vazio</td>
                                @endif
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>

            </section>

        </div>

    </main>

    @include('layout.home.footer')

    <script src="{{ asset('js/bootstrap.min.js') }}"></script>

    <script>

        function solvePendencie(id)
            {
                fetch('{{ route('pendencies.solve') }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ id }),
                    })
                    .then(response => response.json())
                    .then(data => {
                        window.location.reload();
                    })
                    .catch(error => {
                        // Handle any errors
                        console.error(error);
                    });
                }
    </script>

@endsection