<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="jeciane">
    <title>SKYLINE</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">

    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

</head>

<body>

    <header>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="{{ asset('img/logo.png') }}" alt="SKYLINE" width="160">
                </a>
                <ul class="navbar-nav ml-auto">

                    <li class="nav-item">
                        <div class="row align-items-center">
                            <div class="col-sm-3">
                                <img src="{{ asset('img/user.png') }}" alt="Usuário" width="56">
                            </div>
                            <div class="col user-color">
                                <h4>{{ Auth::user()->name }}</h4>
                                <h4>Administrador</h4>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </header>

    <main>

        <div class="container">
            <section class="mt-4">
                <article>
                    <h2 class="text-white">Bem-Vindo(a) {{ Auth::user()->name }}!</h2>
                    <h3 id="data-notificacoes" class="ms-lg-4 ms-md-4 text-white">
                        <span id="data">{{ date('d/m/Y', strtotime('now')) }} | </span>
                        <span id="notificacoes-qntd">{{ $countPendencies }} Notificações</span>
                    </h3>
                </article>
            </section>

            <section class="mt-4">
                <h4 id="pendencias">Pendências</h4>

                <div class="container" id="pendencias-grid">
                    <div class="row column-gap-3">
                        <div class="col" onclick="location.href='{{ route('pendencies.index') }}'">
                            <h3 class="m-3">Atenção</h3>
                            <div class="m-3 d-flex justify-content-between align-items-center">
                                <div>
                                    <h1 class="pendencia-qntd">{{ $countPendencies }}</h1>
                                </div>
                                <div class="alert rounded-circle">
                                    <img src="img/alert.png" alt="alerta" width="60">
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <h3 class="m-3">Horas trabalhadas</h3>
                            <div class="m-3 d-flex justify-content-between align-items-center">
                                <div>
                                    <h1 class="pendencia-qntd">{{ Auth::user()->total_hours }}</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>


        </div>

    </main>

    <footer class="fixed-bottom">

        <div class="d-flex justify-content-between">
            <div class="triangular-box me-5">
                <div class="d-flex justify-content-center">
                    <h1 id="text-contact-footer" class="text-white">Fale com a gente, estamos online!</h1>
                </div>
            </div>
            <div>
                <div class="d-flex justify-content-between align-items-center">
                    <div class="me-3 p-3 rounded-circle border border-3 border-black img-contact">
                        <a href="https://wa.me/+558499790545"><img class="img-contact" src="img/whatsapp-contact.png" alt="" width="60"></a>
                    </div>
                    <div class="me-3 rounded-circle p-3 border border-3 border-black img-contact">
                        <a href="https://www.instagram.com/slupsorvetes/"><img class="img-contact" src="img/instagram-contactor.png" alt="" width="60"></a>
                    </div>
                </div>
            </div>
        </div>


    </footer>

    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
</body>

</html>