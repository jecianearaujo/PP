@extends('layout.base')

@section('title', 'SKYLINE')

@section('head')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endsection

@section('content')

@include('layout.index.header')

<main>

    <div class="container position-fixed centered">
        <section class="">
            <article>
                <h2 class="text-white">Bem-Vindo(a) {{ Auth::user()->name }}!</h2>
                <h3 id="data-notificacoes" class="ms-lg-4 ms-md-4 text-white">
                    <span id="data">{{ date('d/m/Y', strtotime('now')) }} | </span>
                    <span id="notificacoes-qntd">{{ $countPendencies }} Notificações</span>
                </h3>
            </article>
        </section>

        <section class="mt-4">
            <h4 id="pendencias">Pendências</h4>

            <div class="container" id="pendencias-grid">
                <div class="row column-gap-3">
                    <div class="col" onclick="location.href='{{ route('pendencies.index') }}'">
                        <h3 class="m-3">Notificações</h3>
                        <div class="m-3 d-flex justify-content-between align-items-center">
                            <div>
                                <h1 class="pendencia-qntd">{{ $countPendencies }}</h1>
                            </div>
                            <div class="alert rounded-circle">
                                <img src="img/alert.png" alt="alerta" width="60">
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <h3 class="m-3">Resolvidos</h3>
                        <div class="m-3 d-flex justify-content-between align-items-center">
                            <div>
                                @if (Auth::user()->admin == 1)
                                    <h1 class="pendencia-qntd">
                                        {{ \App\Models\Pendencies::where('solved', true)->count() }}
                                    </h1>
                                @else
                                    <h1 class="pendencia-qntd">
                                        {{ \App\Models\Pendencies::where('solved', true)->where('employee_id', Auth::user()->id)->count() }}
                                    </h1>
                                @endif
                                
                            </div>
                            <div class="alert rounded-circle">
                                <img src="img/alert.png" alt="alerta" width="60">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

</main>

@include('layout.index.footer')

@endsection
