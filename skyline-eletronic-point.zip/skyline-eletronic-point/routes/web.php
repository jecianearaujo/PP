<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ColaboradoresController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\PendenciesController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return redirect('/login', 302);
});

Route::get('/index', function() {
    if(!Auth::user()->admin)
        $countPendencies = \App\Models\Pendencies::where('id', Auth::user()->id)->count();
    else
        $countPendencies = \App\Models\Pendencies::all()->count();
    return view('index', ['countPendencies' => $countPendencies]);
})->name('dashboard')->middleware(['auth']);

Route::get('/login', fn () => view('auth.login'))->name('login')->middleware(['guest']);
Route::post('/login', [LoginController::class, 'authenticate'])->name('login.authenticate');
Route::get('/logout', [LoginController::class, 'logout'])->name('login.logout');

Route::get('/home', fn () => view('home'))->middleware(['auth']);

Route::get('/colaboradores', [ColaboradoresController::class, 'index'])
    ->name('colaboradores.index')->middleware(['auth', 'is_admin']);
Route::get('/colaboradores/show', [ColaboradoresController::class, 'show'])
    ->name('colaboradores.show')->middleware(['auth', 'is_admin']);
Route::get('/colaboradores/sync', [ColaboradoresController::class, 'syncEmployees'])
    ->name('colaboradores.sync')->middleware(['auth', 'is_admin']);

Route::get('/pendencies', [PendenciesController::class, 'index'])
    ->name('pendencies.index')->middleware(['auth']);