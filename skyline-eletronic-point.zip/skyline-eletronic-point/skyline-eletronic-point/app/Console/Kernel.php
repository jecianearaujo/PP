<?php

namespace App\Console;

use App\Http\Controllers\ColaboradoresController;
use App\Http\Controllers\PendenciesController;
use App\Http\Controllers\UserController;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule): void
    {
        $schedule->call(function() {
            PendenciesController::getGpsPendencies();
        })->everySixHours();

        $schedule->call(function() {
            UserController::calculatehours();
        })->daily();

        $schedule->call(function() {
            ColaboradoresController::syncEmployees();
        })->daily();
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
