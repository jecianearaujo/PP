<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $fillable = [
        'id',
        'name',
        'email'
    ];

    /**
    * @var int
    */
    protected $primaryKey = 'id';

    /**
     * @var bool
     */
    public $incrementing = false;

    use HasFactory;
}
