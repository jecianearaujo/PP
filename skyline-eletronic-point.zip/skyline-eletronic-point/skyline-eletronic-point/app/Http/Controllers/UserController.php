<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    
    public static function calculatehours()
    {
        $client = new \GuzzleHttp\Client([
            'verify' => false,
            'headers' => ['Authorization' => "Basic Y2Y2NjRhYmZiMzk3NDU5ODhlNTJmYWZjMTBjOTkwYzk6MGU1ZjViZDBlNTE0NDlmMjhkMjQzOGY4ZWQ4MTRkYzA="]
        ]);
        $users = \App\Models\User::where('active', 1)->get();

        foreach($users as $user)
        {
            $points = ColaboradoresController::getPoints($user->id, $client, null, null);
            if($points)
            {
                $totalHours = 0;
                foreach($points['content'] as $point)
                {
                    if($point['status'] == 'APPROVED'){
                        $secondsIn = (int) $point['dateInFull'] / 1000;
                        $secondsOut = (int) $point['dateOutFull'] / 1000;

                        $datetime1 = \DateTime::createFromFormat('U', $secondsIn);
                        $datetime2 = \DateTime::createFromFormat('U', $secondsOut);

                        if(!$datetime1 || !$datetime2){
                            continue;
                        }

                        $interval = $datetime1->diff($datetime2);

                        $hoursDifference = $interval->h;

                        $totalHours += $hoursDifference;
                    }
                }
                \App\Models\User::where('id', $user->id)->update(['total_hours' => $totalHours]);
            }
        }
    }

}
