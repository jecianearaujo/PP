<div class="mt-2 ms-2">
    <button type="button" class="btn btn-primary rounded-pill" onclick="window.location.href = '{{ route('home') }}';">
        <i class="fa fa-home"></i>
    </button>
    <button type="button" class="btn btn-secondary rounded-pill" onclick="window.history.back();">
        <i class="fa fa-arrow-left"></i>
    </button>
</div>