<header>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="{{ route('home') }}">
                <img src="{{ asset('img/logo.png') }}" alt="SKYLINE" width="160">
            </a>
            <ul class="navbar-nav ml-auto">

                <li class="nav-item">
                    <div class="row align-items-center">
                        <div class="col-sm-3">
                            <img src="{{ asset('img/user.png') }}" alt="Usuário" width="56">
                        </div>
                        <div class="col user-color">
                            <h4>{{ Auth::user()->name }}</h4>
                            @if($condition = Auth::user()->admin == 1)
                                <h4>Administrador</h4>
                            @else
                                <h4>Colaborador</h4>
                            @endif
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</header>