@extends('layout.base')

@section('title', 'SKYLINE - Home')

@section('head')
<style>
    .centered-image {
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    #login-btn {
        top: 20px;
        right: 15px;
        color: #1b761b;
    }

    #login-btn:hover{
        color: #165f16;
    }
</style>
@endsection

@section('content')

    <main style="height: 100vh;">

        <article>
            <h5 class="text-white text-center d-inline-block" id="greetings-user">Bem-Vindo(a)</h5>
        </article>

        <button class="btn bg-light rounded-pill position-fixed" id="login-btn" onclick="window.location.href='{{ route('login') }}'">Entrar</button>

        <img src="img/logo.png" class="position-fixed img-fluid centered-image" alt="">

    </main>

    <footer>
        <nav class="navbar fixed-bottom footer-normal" id="navbar-index">
            <div class="container d-flex justify-content-center">
                <div class="row d-flex align-items-center">
                    <div class="col-1 me-5">
                        <a href="{{ route('dashboard') }}"><img src="img/relogio.png" width="60" alt=""></a>
                    </div>
                    <div class="col-1">
                        <a href="{{ route('dashboard') }}"><img src="img/sino.png" width="60" alt=""></a>
                    </div>
                    <div class="col ms-4 d-none d-md-block d-xl-block d-xxl-none">
                        <h4 class="text-white text-center py-4 px-3 rounded-pill" id="footer-message">Suas notificações e pendências aqui!</h4>
                    </div>
                </div>
                
            </div>
            </div>
        </nav>

    </footer>

    <script src="{{ asset('js/bootstrap.min.js') }}"></script>

@endsection