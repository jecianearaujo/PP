@extends('layout.base')

@section('title', 'SKYLINE - Login')

@section('head')
<style>
    body {
        background-color: rgb(93, 143, 85);
    }
</style>
@endsection

@section('content')

    <div class="container">

        @include('layout.alerts')

        <main>
            
            <section class="login">

                <div class="text-center mt-2">
                    <img src="{{ asset('img/logo.png') }}" alt="" width="240px">
                </div>

                <h2 class="text-center text-white my-4">LOGIN</h2>

                <form action="{{ route('login.authenticate') }}" method="post" class="mx-4">
                    @csrf
                    <input class="form-control form-control-lg form-input-bg rounded-pill mb-3" type="text" placeholder="Email" aria-label="email" name="email" required>

                    <input class="form-control form-control-lg form-input-bg rounded-pill mb-4" type="password" placeholder="Senha" aria-label="password" name="password" required>

                    <div class="text-center mb-5">
                        <button class="btn btn-primary rounded-pill px-4" type="submit">Entrar</button>
                    </div>
                </form>

            </section>
            
        </main>
    </div>

@endsection