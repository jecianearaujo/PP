@extends('layout.base')

@section('title', 'SKYLINE - colaboradores')

@section('head')
<link rel="stylesheet" href="{{ asset('css/colaboradores.css') }}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endsection

@section('content')

    @include('layout.header')

    @include('layout.alerts')

    @include('layout.action_btns')

    <main>

        <div class="container-fluid">

            <section class="mt-2">

                <div class="row">
                    <div class="col-md-6">
                        <form action="{{ route('colaboradores.index') }}" method="get">
                            <div class="mb-3">
                                <div class="col">
                                    <label for="colaborador" class="form-label text-secondary-emphasis" id="lbl">Colaborador</label>
                                </div>
                                <div class="position-relative">
                                    <input type="text" id="colaborador" name="colaborador" placeholder="Digite aqui">
                                    <button id="btn-search" type="submit">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" width="30px" height="30px"><path d="M 21 3 C 11.621094 3 4 10.621094 4 20 C 4 29.378906 11.621094 37 21 37 C 24.710938 37 28.140625 35.804688 30.9375 33.78125 L 44.09375 46.90625 L 46.90625 44.09375 L 33.90625 31.0625 C 36.460938 28.085938 38 24.222656 38 20 C 38 10.621094 30.378906 3 21 3 Z M 21 5 C 29.296875 5 36 11.703125 36 20 C 36 28.296875 29.296875 35 21 35 C 12.703125 35 6 28.296875 6 20 C 6 11.703125 12.703125 5 21 5 Z"/></svg>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-6 d-flex flex-column justify-content-end">
                        <div class="mb-3">
                        <div class="col"></div> 
                        <div class="col" style="text-align: end">
                            <button class="btn" id="btn-pendencie-refresh" onclick="window.location.href = '{{ route('colaboradores.refresh') }}';">
                                <img src="{{ asset('img/refresh_btn.svg') }}" alt="atualizar">
                            </button>
                        </div>
                    </div>
                    </div>

                </div>

                <div class="table-responsive table-mb">

                <table class="table caption-top table-sm mt-2">
                    <caption>{{ count($users) }} colaboradores</caption>
                    <thead>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Ações</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Colaborador</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Email</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Data</p></th>
                    </thead>
                    <tbody>
                        @foreach ($users as $colaborador)
                            @continue($colaborador->id == 1)
                            <tr>
                                <td>
                                    @if (count($colaborador->pendencie->where('solved', false)) > 0)
                                        <img src="{{ asset('img/warning.png') }}" alt="" width="32" data-bs-toggle="modal" data-bs-target="#modal" user-id="{{ $colaborador->id }}"></td>
                                    @endif
                                <td><a
                                        href="{{ route('colaboradores.show', ['id' => $colaborador->id]) }}">{{ $colaborador->name }}</a>
                                </td>
                                <td>
                                    @if ($colaborador->email)
                                        {{ $colaborador->email }}
                                    @else
                                        Não possui
                                    @endif

                                <td>03/05/2023</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>

                </div>

            </section>

        </div>

        <div class="modal fade" id="modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content" id="modal-colaboradores">
                <div class="modal-header">
                  <h1 class="modal-title fs-5 p-2" id="modal-label">Ações</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table class="table table-sm table-borderless" id="table-colaboradores-modal">
                    <thead id="thead-modal">
                        <th>Data</th>
                        <th>Observação</th>
                        <th>Ação</th>
                    </thead>
                    <tbody>
                        
                    </tbody>
                      </table>
                </div>
              </div>
            </div>
          </div>


    </main>

    @include('layout.home.footer')

    <script>

        const modal = document.getElementById('modal')
        if (modal) {
        modal.addEventListener('show.bs.modal', event => {
            
            const button = event.relatedTarget

            const userId = button.getAttribute('user-id')

            const modalTitle = modal.querySelector('.modal-title')
            const modalBody = modal.querySelector('.modal-body')

            const table = document.getElementById('table-colaboradores-modal');

            fetch(`{{ route('pendencies.find') }}?id=${userId}`)
                .then(response => response.json())
                .then(data => {
                    console.log(data);

                    const rows = table.querySelector('tbody').querySelectorAll("tr");

                    rows.forEach(row => {
                        row.remove();
                    });

                    data.forEach(element => {
                        const newRow = document.createElement('tr');
    
                        const date = new Date(element.date_in);
                        if(date === null){
                            dateFormatted = "vazio";
                        }else {
                            dateFormatted = `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
                        }

                        const dateCell = document.createElement('td');
                        dateCell.textContent = `${dateFormatted}`;
                        const observacoesCell = document.createElement('td');
                        observacoesCell.textContent = `${element.description}`;
                        const acaoCell = document.createElement('td');
                        const acaoBtn = document.createElement('button');
                        acaoBtn.textContent = "resolver";
                        acaoBtn.classList.add("btn", "btn-sm", "rounded-pill");
                        acaoBtn.style.backgroundColor = "rgb(166, 237, 154)";
                        acaoBtn.onclick = () => solvePendencie(element.id);
                        acaoCell.appendChild(acaoBtn);

                        newRow.appendChild(dateCell);
                        newRow.appendChild(observacoesCell);
                        newRow.appendChild(acaoCell);
    
                        table.querySelector('tbody').appendChild(newRow);
                        
                    });

                })
                .catch(error => {
                    console.error(error);
            });
        })
    }

    function solvePendencie(id)
    {
        fetch('{{ route('pendencies.solve') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id }),
            })
            .then(response => response.json())
            .then(data => {
                window.location.reload();
            })
            .catch(error => {
                console.error(error);
            });
        }

    </script>

@endsection