@extends('layout.base')

@section('title', 'SKYLINE - Colaborador')

@section('head')
    <link rel="stylesheet" href="{{ asset('css/colaboradores.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endsection

@section('content')

    @include('layout.header')

    @include('layout.action_btns')

    <main>

        <div class="container-fluid">

            <section class="mt-2">

                <article>
                    <p>Nome: {{ $colaborador['name'] }}</p>
                    @if (array_key_exists('cpf', $colaborador))
                        <p>Cpf: {{ $colaborador['cpf'] }}</p>
                    @endif
                    <p>Email: {{ $colaborador['email'] }}</p>
                    @if (array_key_exists('phone', $colaborador))
                        <p>Celular: {{ $colaborador['phone'] }}</p>
                    @endif
                    <p>Cargo: {{ $colaborador['jobRoleDTO']['description'] }}</p>
                </article>

            </section>

            <section>
                
                <div>
                    <form action="" method="GET">
                        <div class="input-group">
                            <span class="input-group-text">Filtrar por datas</span>
                            <input type="date" pattern="\d{2}\/\d{2}\/\d{4}" aria-label="Inicio" class="form-control" value="{{ old('startDate', request()->input('startDate'))}}" placeholder="Data de inicio" name="startDate" required>
                            <input type="date" pattern="\d{2}\/\d{2}\/\d{4}" aria-label="Fim" class="form-control" value="{{ old('endDate', request()->input('endDate'))}}" placeholder="Data de fim" name="endDate" required>
                            <input type="hidden" value="{{ $colaborador['id'] }}" name="id">
                            <button class="btn btn-primary" style="background-color: rgb(166, 237, 154); color: rgb(42, 131, 40); border: none;" type="submit">Buscar</button>
                        </div>
                    </form>
                </div>

                <div class="table-responsive table-mb">

                    <table class="table caption-top table-sm mt-2">
                        <caption>{{ count($timeSheet['content']) }} registros</caption>
                        <thead>
                            <th>
                                <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Data</p>
                            </th>
                            <th>
                                <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Entrada</p>
                            </th>
                            <th>
                                <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Saida</p>
                            </th>
                            <th>
                                <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Status</p>
                            </th>
                        </thead>
                        <tbody>
                            @isset($timeSheet)
                                @foreach ($timeSheet['content'] as $point)
                                    <tr class="table-warning">
                                        <td>{{ \Carbon\Carbon::createFromFormat('Y-m-d', $point['date'])->format('d/m/Y') }}</td>
                                        <td>{{ \Carbon\Carbon::createFromTimestampMs($point['dateIn'])->format('d/m/Y H:i:s')}}</td>
                                        @if ($point['dateOut'] != null)
                                            <td>{{ \Carbon\Carbon::createFromTimestampMs($point['dateOut'])->format('d/m/Y H:i:s')}}</td>
                                        @else
                                            <td>Vazio</td>
                                        @endif
                                        <td>
                                            @if($point['status'] == "PENDING")
                                                Pendente
                                            @elseif($point['status'] == "APPROVED")
                                                Aprovado
                                            @elseif($point['status'] == "REJECTED")
                                                Rejeitado
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            @endisset
                        </tbody>
                    </table>
                </div>
            </section>

        </div>

        <div class="modal fade" id="modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content" id="modal-colaboradores">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5 p-2" id="modal-label">Ações</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-sm table-borderless" id="table-colaboradores-modal">
                            <thead id="thead-modal">
                                <th>Data</th>
                                <th>Observações</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>06/11/2023 - 07:30</td>
                                    <td>GPS desabilitado</td>
                                </tr>
                                <tr>
                                    <td>06/11/2023 - 07:30</td>
                                    <td>GPS desabilitado</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </main>

    @include('layout.home.footer')

@endsection