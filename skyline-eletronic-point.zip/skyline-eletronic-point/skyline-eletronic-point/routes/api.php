<?php

use App\Models\Pendencies;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/pendencies/find', function (Request $request) {
    // select Pendencies where employee_id and solved is false
    $pendencies = Pendencies::where('employee_id', $request->id)
        ->where('solved', false)
        ->with('user')
        ->get();
    $result = json_encode($pendencies);
    return $result;
})->name('pendencies.find');

Route::post('/pendencies/solve', function (Request $request) {
    if (!isset($request->id)) {
        return response()->json(['message' => 'The id of the pendency must be sent in the request body.'], 404);
    }

    $pendencies = Pendencies::where('id', $request->id)->first();
    $pendencies->solved = true;
    $pendencies->save();
    return response()->json(['message' => 'Updated with successfully.', 200]);
})->name('pendencies.solve');
