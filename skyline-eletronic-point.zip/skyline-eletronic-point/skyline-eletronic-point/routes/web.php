<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ColaboradoresController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\PendenciesController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return redirect('/home', 302);
});

Route::get('/index', function() {
    if(!Auth::user()->admin)
        $countPendencies = \App\Models\Pendencies::where('employee_id', Auth::user()->id)
            ->where('solved', false)->count();
    else
        $countPendencies = \App\Models\Pendencies::where('solved', false)->count();
    return view('index', ['countPendencies' => $countPendencies]);
})->name('dashboard')->middleware(['auth']);

Route::get('/home', fn () => view('home'))->name('home');
Route::get('/login', fn () => view('auth.login'))->name('login')->middleware(['guest']);
Route::post('/login', [LoginController::class, 'authenticate'])->name('login.authenticate');
Route::get('/logout', [LoginController::class, 'logout'])->name('login.logout');

Route::middleware(['auth', 'is_admin'])->group(function () {
    Route::get('/colaboradores', [ColaboradoresController::class, 'index'])
        ->name('colaboradores.index');
    Route::get('/colaboradores/show', [ColaboradoresController::class, 'show'])
        ->name('colaboradores.show');
    Route::get('/colaboradores/sync', [ColaboradoresController::class, 'syncEmployees'])
        ->name('colaboradores.sync');
    Route::get('/colaboradores/refresh', [ColaboradoresController::class, 'refreshEmployees'])
        ->name('colaboradores.refresh');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/pendencies', [PendenciesController::class, 'index'])
        ->name('pendencies.index');
    Route::get('/pendencies/refresh', [PendenciesController::class, 'refreshPendencies'])
        ->name('pendencies.refresh');
});
