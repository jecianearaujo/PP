

<?php $__env->startSection('title', 'SKYLINE - Home'); ?>

<?php $__env->startSection('head'); ?>
<style>
    .centered-image {
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    .auth-btn {
        top: 20px;
        right: 15px;
    }

    #login-btn {
        color: #1b761b;
    }

    #logout-btn {
        color: rgb(124, 179, 115);
    }

    .auth-btn:hover{
        color: #165f16 !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <main style="height: 100vh;">

        <article>
            <h5 class="text-white text-center d-inline-block" id="greetings-user">
                Bem-Vindo(a) <?php if(Auth::user()): ?> <?php echo e(Auth::user()->name); ?> <?php endif; ?>
            </h5>
        </article>

        <?php if(Auth::guest()): ?>
            <button class="btn bg-light rounded-pill position-fixed auth-btn" id="login-btn" onclick="window.location.href='<?php echo e(route('login')); ?>'">Entrar</button>
        <?php else: ?>
            <button class="btn bg-danger rounded-pill position-fixed auth-btn" id="logout-btn" onclick="window.location.href='<?php echo e(route('login.logout')); ?>'">Sair</button>
        <?php endif; ?>

        <img src="img/logo.png" class="position-fixed img-fluid centered-image" alt="">

    </main>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeciane\Desktop\skyline-eletronic-point\skyline-eletronic-point\resources\views/home.blade.php ENDPATH**/ ?>