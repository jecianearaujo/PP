<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="jeciane">
    <title>SKYLINE</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/colaboradores.css')); ?>">

</head>

<body>

    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>

        <div class="container-fluid">

            <section class="mt-5">
                <form action="<?php echo e(route('colaboradores.index')); ?>" method="get">
                    <div class="mb-3">
                        <label for="colaborador" class="form-label" id="lbl">Colaborador</label>
                        <input type="text" class="form-control" id="colaborador" name="colaborador">
                    </div>
                </form>

                <div class="table-responsive table-mb">

                <table class="table caption-top table-sm mt-2">
                    <caption><?php echo e(count($users)); ?> colaboradores</caption>
                    <thead>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Ações</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Colaborador</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Email</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Data</p></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colaborador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if(count($colaborador->pendencie) > 0): ?>
                                    <img src="<?php echo e(asset('img/warning.png')); ?>" alt="" width="32" data-bs-toggle="modal" data-bs-target="#modal" user-id="<?php echo e($colaborador->id); ?>"></td>
                                    <?php endif; ?>
                                <td><a
                                        href="<?php echo e(route('colaboradores.show', ['id' => $colaborador->id])); ?>"><?php echo e($colaborador->name); ?></a>
                                </td>
                                <td>
                                    <?php if($colaborador->email): ?>
                                        <?php echo e($colaborador->email); ?>

                                    <?php else: ?>
                                        Não possui
                                    <?php endif; ?>

                                <td>03/05/2023</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                </div>

            </section>

        </div>

        <div class="modal fade" id="modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content" id="modal-colaboradores">
                <div class="modal-header">
                  <h1 class="modal-title fs-5 p-2" id="modal-label">Ações</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <table class="table table-sm table-borderless" id="table-colaboradores-modal">
                    <thead id="thead-modal">
                        <th>Data</th>
                        <th>Observação</th>
                        <th>Ação</th>
                    </thead>
                    <tbody>
                        
                    </tbody>
                      </table>
                </div>
              </div>
            </div>
          </div>


    </main>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <script>

        const modal = document.getElementById('modal')
        if (modal) {
        modal.addEventListener('show.bs.modal', event => {
            
            const button = event.relatedTarget

            const userId = button.getAttribute('user-id')

            const modalTitle = modal.querySelector('.modal-title')
            const modalBody = modal.querySelector('.modal-body')

            const table = document.getElementById('table-colaboradores-modal');

            fetch(`<?php echo e(route('pendencies.find')); ?>?id=${userId}`)
                .then(response => response.json())
                .then(data => {
                    console.log(data);

                    const rows = table.querySelector('tbody').querySelectorAll("tr");

                    rows.forEach(row => {
                        row.remove();
                    });

                    data.forEach(element => {
                        const newRow = document.createElement('tr');
    
                        const date = new Date(element.date_in);
                        if(date === null){
                            dateFormatted = "vazio";
                        }else {
                            dateFormatted = `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
                        }

                        const dateCell = document.createElement('td');
                        dateCell.textContent = `${dateFormatted}`;
                        const observacoesCell = document.createElement('td');
                        observacoesCell.textContent = `${element.description}`;
                        const acaoCell = document.createElement('td');
                        const acaoBtn = document.createElement('button');
                        acaoBtn.textContent = "resolver";
                        acaoBtn.classList.add("btn", "btn-sm", "rounded-pill");
                        acaoBtn.style.backgroundColor = "rgb(166, 237, 154)";
                        acaoBtn.onclick = () => solvePendencie(element.id);
                        acaoCell.appendChild(acaoBtn);

                        newRow.appendChild(dateCell);
                        newRow.appendChild(observacoesCell);
                        newRow.appendChild(acaoCell);
    
                        table.querySelector('tbody').appendChild(newRow);
                        
                    });

                })
                .catch(error => {
                    console.error(error);
            });
        })
    }

    function solvePendencie(id)
    {
        fetch('<?php echo e(route('pendencies.solve')); ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id }),
            })
            .then(response => response.json())
            .then(data => {
                window.location.reload();
            })
            .catch(error => {
                console.error(error);
            });
        }

    </script>

</body>

</html>
<?php /**PATH C:\Users\jeciane\Documents\jeciane\skyline-eletronic-point\resources\views/colaboradores/index.blade.php ENDPATH**/ ?>