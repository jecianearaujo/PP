<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="author" content="jeciane">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Gugi&display=swap" rel="stylesheet"> 

    <?php echo $__env->yieldContent('head'); ?>

</head>
<body>

    <?php echo $__env->yieldContent('content'); ?>
    
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\jeciane\Desktop\skyline-eletronic-point\skyline-eletronic-point\resources\views/layout/base.blade.php ENDPATH**/ ?>