<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SKYLINE - Home</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>

<body>

    <main>

        <article>
            <h5 class="text-white text-center d-inline-block" id="greetings-user">Bem-Vindo(a) <?php echo e(Auth::user()->name); ?></h5>
        </article>

        <section id="logo-presentation">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="text-center d-none d-md-block d-xl-block d-xxl-none p-4">Tudo em um só lugar!</h2>
                </div>
                <div class="mx-md-auto mx-sm-auto mx-lg-0">
                    <img src="img/logo.png" class="img-fluid" alt="">
                </div>
            </div>
        </section>

    </main>

    <footer>
        <nav class="navbar fixed-bottom footer-normal" id="navbar-index">
            <div class="container d-flex justify-content-center">
                <div class="row d-flex align-items-center">
                    <div class="col-1 me-5">
                        <a href="<?php echo e(route('dashboard')); ?>"><img src="img/relogio.png" width="60" alt=""></a>
                    </div>
                    <div class="col-1">
                        <a href="<?php echo e(route('dashboard')); ?>"><img src="img/sino.png" width="60" alt=""></a>
                    </div>
                    <div class="col ms-4 d-none d-md-block d-xl-block d-xxl-none">
                        <h4 class="text-white text-center py-4 px-3 rounded-pill" id="footer-message">Suas notificações e horas excedentes aqui!</h4>
                    </div>
                </div>
                
            </div>
            </div>
        </nav>

    </footer>

    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\jeciane\Documents\jeciane\skyline-eletronic-point\resources\views/home.blade.php ENDPATH**/ ?>