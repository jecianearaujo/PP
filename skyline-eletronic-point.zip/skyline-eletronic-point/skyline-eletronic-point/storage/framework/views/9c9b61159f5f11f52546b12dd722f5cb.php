<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="jeciane">
    <title>SKYLINE</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/colaboradores.css')); ?>">

</head>

<body>

    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>

        <div class="container-fluid">

            <section class="mt-5">
                <?php if(Auth::user()->admin): ?>
                <form action="<?php echo e(route('pendencies.index')); ?>" method="get">
                    <div class="mb-3">
                        <label for="colaborador" class="form-label" id="lbl">Colaborador</label>
                        <input type="text" class="form-control" id="colaborador" name="colaborador">
                    </div>
                </form>
                <?php endif; ?>

                <div class="table-responsive table-mb">

                <table class="table caption-top table-sm mt-2">
                    <caption><?php echo e(count($pendencies)); ?> pendências</caption>
                    <thead>
                        <?php if(Auth::user()->admin): ?>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Ações</p></th>
                        <?php endif; ?>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Colaborador</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Descrição</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Entrada</p></th>
                        <th>
                            <p class="th-text p-2 rounded-pill fw-bold p-rm-pad-bottom">Saída</p>
                        </th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendencie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if(Auth::user()->admin): ?>
                                    <td><button class="btn btn-primary btn-sm rounded-pill form-input-bg" onclick="solvePendencie(<?php echo e($pendencie->id); ?>)">Resolver</button></td>
                                    <td>
                                        <a href="<?php echo e(route('colaboradores.show', ['id' => $pendencie->user->id])); ?>"><?php echo e($pendencie->user->name); ?></a>
                                        
                                        </td>
                                    <?php else: ?>
                                        <td><?php echo e($pendencie->user->name); ?></td>
                                    <?php endif; ?>
                                    
                                <td><?php echo e($pendencie->description); ?></td>
                                <?php if($pendencie->date_in != null): ?>
                                    <td><?php echo e(\Carbon\Carbon::createFromTimestampMs($pendencie->date_in)->format('d/m/Y H:i:s')); ?></td>
                                <?php else: ?>
                                    <td>Vazio</td>
                                <?php endif; ?>
                                <?php if($pendencie->date_out != null): ?>
                                    <td><?php echo e(\Carbon\Carbon::createFromTimestampMs($pendencie->date_out)->format('d/m/Y H:i:s')); ?></td>
                                <?php else: ?>
                                    <td>Vazio</td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>

            </section>

        </div>

        <div class="modal fade" id="modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content" id="modal-colaboradores">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5 p-2" id="modal-label">Ações</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-sm table-borderless" id="table-colaboradores-modal">
                            <thead id="thead-modal">
                                <th>Data</th>
                                <th>Observações</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>06/11/2023 - 07:30</td>
                                    <td>GPS desabilitado</td>
                                </tr>
                                <tr>
                                    <td>06/11/2023 - 07:30</td>
                                    <td>GPS desabilitado</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </main>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

    <script>

        function solvePendencie(id)
            {
                fetch('<?php echo e(route('pendencies.solve')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        // Add any other headers if required
                    },
                    // Add the request body if needed
                    body: JSON.stringify({ id }),
                    })
                    .then(response => response.json())
                    .then(data => {
                        window.location.reload();
                    })
                    .catch(error => {
                        // Handle any errors
                        console.error(error);
                    });
                }

    </script>

</body>

</html>
<?php /**PATH C:\Users\jeciane\Documents\jeciane\skyline-eletronic-point\resources\views/pendencies/index.blade.php ENDPATH**/ ?>